-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Lun 10 Avril 2017 à 11:48
-- Version du serveur :  5.7.14
-- Version de PHP :  7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `speedjob`
--

-- --------------------------------------------------------

--
-- Structure de la table `administrateur`
--

CREATE TABLE `administrateur` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(25) DEFAULT NULL,
  `admin_mail` varchar(50) DEFAULT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vider la table avant d'insérer `administrateur`
--

TRUNCATE TABLE `administrateur`;
--
-- Contenu de la table `administrateur`
--

INSERT INTO `administrateur` (`admin_id`, `admin_name`, `admin_mail`, `uid`) VALUES
(1, 'kfossey', 'kilyan.fossey@imie-rennes.fr', 1),
(2, 'nlepiez', 'nicolas.lepiez@imie-rennes.fr', 2);

-- --------------------------------------------------------

--
-- Structure de la table `campus`
--

CREATE TABLE `campus` (
  `camp_id` int(11) NOT NULL,
  `camp_name` varchar(25) DEFAULT NULL,
  `camp_lat` float DEFAULT NULL,
  `camp_lng` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vider la table avant d'insérer `campus`
--

TRUNCATE TABLE `campus`;
--
-- Contenu de la table `campus`
--

INSERT INTO `campus` (`camp_id`, `camp_name`, `camp_lat`, `camp_lng`) VALUES
(1, 'Rennes', NULL, NULL),
(2, 'Caen', NULL, NULL),
(3, 'Nantes', NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `diplome`
--

CREATE TABLE `diplome` (
  `dip_id` int(11) NOT NULL,
  `dip_name` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vider la table avant d'insérer `diplome`
--

TRUNCATE TABLE `diplome`;
-- --------------------------------------------------------

--
-- Structure de la table `entreprise`
--

CREATE TABLE `entreprise` (
  `entr_id` int(11) NOT NULL,
  `entr_socRea` varchar(50) DEFAULT NULL,
  `entr_contact` varchar(50) DEFAULT NULL,
  `entr_mail` varchar(50) DEFAULT NULL,
  `entr_status` tinyint(4) DEFAULT NULL,
  `entr_crea` year(4) DEFAULT NULL,
  `entr_nbEmp` int(11) DEFAULT NULL,
  `entr_resume` text,
  `entr_actArea` varchar(50) DEFAULT NULL,
  `entr_phone` int(11) DEFAULT NULL,
  `entr_street` varchar(25) DEFAULT NULL,
  `entr_streetNum` int(11) DEFAULT NULL,
  `entr_postalCode` int(11) DEFAULT NULL,
  `entr_city` varchar(25) DEFAULT NULL,
  `entr_webSite` varchar(70) DEFAULT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vider la table avant d'insérer `entreprise`
--

TRUNCATE TABLE `entreprise`;
-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

CREATE TABLE `etudiant` (
  `etud_id` int(11) NOT NULL,
  `etud_lastname` varchar(50) DEFAULT NULL,
  `etud_firstname` varchar(50) DEFAULT NULL,
  `etud_birthdate` date DEFAULT NULL,
  `etud_photo` varchar(100) DEFAULT NULL,
  `etud_mail` varchar(100) DEFAULT NULL,
  `etud_status` tinyint(4) DEFAULT NULL,
  `etud_search` tinyint(1) DEFAULT NULL,
  `etud_city` varchar(25) DEFAULT NULL,
  `etud_exp` text,
  `etud_desc` text,
  `etud_income` float DEFAULT NULL,
  `etud_comp` text,
  `etud_cv` varchar(25) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `dip_id` int(11) DEFAULT NULL,
  `prom_id` int(11) DEFAULT NULL,
  `camp_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vider la table avant d'insérer `etudiant`
--

TRUNCATE TABLE `etudiant`;
--
-- Contenu de la table `etudiant`
--

INSERT INTO `etudiant` (`etud_id`, `etud_lastname`, `etud_firstname`, `etud_birthdate`, `etud_photo`, `etud_mail`, `etud_status`, `etud_search`, `etud_city`, `etud_exp`, `etud_desc`, `etud_income`, `etud_comp`, `etud_cv`, `uid`, `dip_id`, `prom_id`, `camp_id`) VALUES
(1, 'fossey', 'kilyan', '1996-09-01', NULL, 'kilyan.fossey@imie-rennes.fr', 1, 0, 'Bruz', NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL),
(2, 'lepiez', 'nicolas', '1789-07-14', NULL, 'nicolas.lepiez@imie-rennes.fr', 1, 0, 'Rennes', NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `offre`
--

CREATE TABLE `offre` (
  `offre_id` int(11) NOT NULL,
  `offre_status` tinyint(4) DEFAULT NULL,
  `offre_validDate` date DEFAULT NULL,
  `offre_debDate` date DEFAULT NULL,
  `offre_duree` varchar(25) DEFAULT NULL,
  `offre_lvl` varchar(25) DEFAULT NULL,
  `offre_intulePoste` varchar(25) DEFAULT NULL,
  `offre_descMission` text,
  `offre_comp` text,
  `offre_remun` float DEFAULT NULL,
  `entr_id` int(11) DEFAULT NULL,
  `uid` int(11) NOT NULL,
  `cont_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vider la table avant d'insérer `offre`
--

TRUNCATE TABLE `offre`;
-- --------------------------------------------------------

--
-- Structure de la table `promo`
--

CREATE TABLE `promo` (
  `prom_id` int(11) NOT NULL,
  `prom_name` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vider la table avant d'insérer `promo`
--

TRUNCATE TABLE `promo`;
-- --------------------------------------------------------

--
-- Structure de la table `typecontrat`
--

CREATE TABLE `typecontrat` (
  `cont_id` int(11) NOT NULL,
  `cont_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vider la table avant d'insérer `typecontrat`
--

TRUNCATE TABLE `typecontrat`;
-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `uid` int(11) NOT NULL,
  `usr_login` varchar(25) NOT NULL,
  `usr_password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vider la table avant d'insérer `utilisateur`
--

TRUNCATE TABLE `utilisateur`;
--
-- Contenu de la table `utilisateur`
--

INSERT INTO `utilisateur` (`uid`, `usr_login`, `usr_password`) VALUES
(1, 'kfossey', '1234'),
(2, 'nlepiez', '1234');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `administrateur`
--
ALTER TABLE `administrateur`
  ADD PRIMARY KEY (`admin_id`,`uid`),
  ADD KEY `FK_Administrateur_uid` (`uid`);

--
-- Index pour la table `campus`
--
ALTER TABLE `campus`
  ADD PRIMARY KEY (`camp_id`);

--
-- Index pour la table `diplome`
--
ALTER TABLE `diplome`
  ADD PRIMARY KEY (`dip_id`);

--
-- Index pour la table `entreprise`
--
ALTER TABLE `entreprise`
  ADD PRIMARY KEY (`entr_id`,`uid`),
  ADD KEY `FK_Entreprise_uid` (`uid`);

--
-- Index pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD PRIMARY KEY (`etud_id`,`uid`),
  ADD KEY `FK_Etudiant_uid` (`uid`),
  ADD KEY `FK_Etudiant_dip_id` (`dip_id`),
  ADD KEY `FK_Etudiant_prom_id` (`prom_id`),
  ADD KEY `FK_Etudiant_camp_id` (`camp_id`);

--
-- Index pour la table `offre`
--
ALTER TABLE `offre`
  ADD PRIMARY KEY (`offre_id`),
  ADD KEY `FK_Offres_entr_id` (`entr_id`),
  ADD KEY `FK_Offres_uid` (`uid`),
  ADD KEY `FK_Offres_cont_id` (`cont_id`);

--
-- Index pour la table `promo`
--
ALTER TABLE `promo`
  ADD PRIMARY KEY (`prom_id`);

--
-- Index pour la table `typecontrat`
--
ALTER TABLE `typecontrat`
  ADD PRIMARY KEY (`cont_id`);

--
-- Index pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `administrateur`
--
ALTER TABLE `administrateur`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `campus`
--
ALTER TABLE `campus`
  MODIFY `camp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `diplome`
--
ALTER TABLE `diplome`
  MODIFY `dip_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `entreprise`
--
ALTER TABLE `entreprise`
  MODIFY `entr_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `etudiant`
--
ALTER TABLE `etudiant`
  MODIFY `etud_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `offre`
--
ALTER TABLE `offre`
  MODIFY `offre_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `promo`
--
ALTER TABLE `promo`
  MODIFY `prom_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `typecontrat`
--
ALTER TABLE `typecontrat`
  MODIFY `cont_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `administrateur`
--
ALTER TABLE `administrateur`
  ADD CONSTRAINT `FK_Administrateur_uid` FOREIGN KEY (`uid`) REFERENCES `utilisateur` (`uid`);

--
-- Contraintes pour la table `entreprise`
--
ALTER TABLE `entreprise`
  ADD CONSTRAINT `FK_Entreprise_uid` FOREIGN KEY (`uid`) REFERENCES `utilisateur` (`uid`);

--
-- Contraintes pour la table `etudiant`
--
ALTER TABLE `etudiant`
  ADD CONSTRAINT `FK_Etudiant_camp_id` FOREIGN KEY (`camp_id`) REFERENCES `campus` (`camp_id`),
  ADD CONSTRAINT `FK_Etudiant_dip_id` FOREIGN KEY (`dip_id`) REFERENCES `diplome` (`dip_id`),
  ADD CONSTRAINT `FK_Etudiant_prom_id` FOREIGN KEY (`prom_id`) REFERENCES `promo` (`prom_id`),
  ADD CONSTRAINT `FK_Etudiant_uid` FOREIGN KEY (`uid`) REFERENCES `utilisateur` (`uid`);

--
-- Contraintes pour la table `offre`
--
ALTER TABLE `offre`
  ADD CONSTRAINT `FK_Offres_cont_id` FOREIGN KEY (`cont_id`) REFERENCES `typecontrat` (`cont_id`),
  ADD CONSTRAINT `FK_Offres_entr_id` FOREIGN KEY (`entr_id`) REFERENCES `entreprise` (`entr_id`),
  ADD CONSTRAINT `FK_Offres_uid` FOREIGN KEY (`uid`) REFERENCES `utilisateur` (`uid`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
